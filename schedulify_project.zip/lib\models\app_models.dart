import 'package:flutter/material.dart';

// ============ TASK MODEL ============
class Task {
  final String id;
  String title;
  String description;
  String category;
  DateTime dueDate;
  TaskStatus status;
  TaskPriority priority;
  bool isCompleted;

  Task({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.dueDate,
    required this.status,
    required this.priority,
    this.isCompleted = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'category': category,
        'dueDate': dueDate.toIso8601String(),
        'status': status.index,
        'priority': priority.index,
        'isCompleted': isCompleted,
      };

  factory Task.fromJson(Map<String, dynamic> json) => Task(
        id: json['id'],
        title: json['title'],
        description: json['description'],
        category: json['category'],
        dueDate: DateTime.parse(json['dueDate']),
        status: TaskStatus.values[json['status']],
        priority: TaskPriority.values[json['priority']],
        isCompleted: json['isCompleted'],
      );

  Task copyWith({
    String? title,
    String? description,
    String? category,
    DateTime? dueDate,
    TaskStatus? status,
    TaskPriority? priority,
    bool? isCompleted,
  }) {
    return Task(
      id: id,
      title: title ?? this.title,
      description: description ?? this.description,
      category: category ?? this.category,
      dueDate: dueDate ?? this.dueDate,
      status: status ?? this.status,
      priority: priority ?? this.priority,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }
}

enum TaskStatus { urgent, assigned, inProgress, done }
enum TaskPriority { high, medium, low }

// ============ SCHEDULE MODEL ============
class ScheduleItem {
  final String id;
  final String title;
  final String location;
  final String instructor;
  final TimeOfDay time;
  final int durationMinutes;
  final ScheduleType type;
  final Color color;
  final DateTime date;

  ScheduleItem({
    required this.id,
    required this.title,
    required this.location,
    required this.instructor,
    required this.time,
    required this.durationMinutes,
    required this.type,
    required this.color,
    required this.date,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'location': location,
        'instructor': instructor,
        'hour': time.hour,
        'minute': time.minute,
        'durationMinutes': durationMinutes,
        'type': type.index,
        'color': color.value,
        'date': date.toIso8601String(),
      };

  factory ScheduleItem.fromJson(Map<String, dynamic> json) => ScheduleItem(
        id: json['id'],
        title: json['title'],
        location: json['location'],
        instructor: json['instructor'],
        time: TimeOfDay(hour: json['hour'], minute: json['minute']),
        durationMinutes: json['durationMinutes'],
        type: ScheduleType.values[json['type']],
        color: Color(json['color']),
        date: DateTime.parse(json['date']),
      );
}

enum ScheduleType { lecture, labSession, studio, online, generalClass }

// ============ NOTIFICATION MODEL ============
class AppNotification {
  final String id;
  final String title;
  final String body;
  final DateTime timestamp;
  final bool isOverdue;
  bool isRead;

  AppNotification({
    required this.id,
    required this.title,
    required this.body,
    required this.timestamp,
    this.isOverdue = false,
    this.isRead = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'timestamp': timestamp.toIso8601String(),
        'isOverdue': isOverdue,
        'isRead': isRead,
      };

  factory AppNotification.fromJson(Map<String, dynamic> json) => AppNotification(
        id: json['id'],
        title: json['title'],
        body: json['body'],
        timestamp: DateTime.parse(json['timestamp']),
        isOverdue: json['isOverdue'],
        isRead: json['isRead'],
      );
}

// ============ DUMMY DATA ============
class DummyData {
  static List<Task> get initialTasks => [
        Task(
          id: '1',
          title: 'English Literature Essay',
          description: 'Write a critical analysis essay',
          category: 'Humanities',
          dueDate: DateTime.now().add(const Duration(hours: 1)),
          status: TaskStatus.urgent,
          priority: TaskPriority.high,
          isCompleted: false,
        ),
        Task(
          id: '2',
          title: 'Calculus Problem Set 4',
          description: 'Solve integration and differentiation problems',
          category: 'STEM',
          dueDate: DateTime.now().add(const Duration(days: 2)),
          status: TaskStatus.assigned,
          priority: TaskPriority.medium,
          isCompleted: false,
        ),
      ];

  static List<ScheduleItem> getScheduleForDate(DateTime date) {
    final weekday = date.weekday;
    switch (weekday) {
      case DateTime.monday:
        return [
          ScheduleItem(
            id: 's1',
            title: 'Mobile Programming',
            location: 'KU1.02.08',
            instructor: 'Dr. Sarah Kim',
            time: const TimeOfDay(hour: 7, minute: 30),
            durationMinutes: 180,
            type: ScheduleType.lecture,
            color: const Color(0xFF3B5BDB),
            date: date,
          ),
          ScheduleItem(
            id: 's2',
            title: 'Cloud Computing',
            location: 'Studio 4, North Wing',
            instructor: 'Prof. James Lee',
            time: const TimeOfDay(hour: 13, minute: 30),
            durationMinutes: 180,
            type: ScheduleType.studio,
            color: const Color(0xFF2F9E44),
            date: date,
          ),
        ];
      default:
        return [];
    }
  }

  static String getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good Morning';
    if (hour < 17) return 'Good Afternoon';
    return 'Good Evening';
  }

  static String formatTimeOfDay(TimeOfDay time) {
    final hour = time.hour;
    final minute = time.minute.toString().padLeft(2, '0');
    final period = hour < 12 ? 'AM' : 'PM';
    final displayHour = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
    return '${displayHour.toString().padLeft(2, '0')}:$minute\n$period';
  }

  static String getScheduleTypeLabel(ScheduleType type) {
    switch (type) {
      case ScheduleType.lecture: return 'LECTURE';
      case ScheduleType.labSession: return 'LAB SESSION';
      case ScheduleType.studio: return 'STUDIO';
      case ScheduleType.online: return 'ONLINE';
      case ScheduleType.generalClass: return 'CLASS';
    }
  }

  static Color getScheduleTypeColor(ScheduleType type) {
    switch (type) {
      case ScheduleType.labSession: return const Color(0xFF2F9E44);
      case ScheduleType.lecture: return const Color(0xFF7048E8);
      case ScheduleType.studio: return const Color(0xFF3B5BDB);
      case ScheduleType.online: return const Color(0xFFE67700);
      case ScheduleType.generalClass: return const Color(0xFFE64980);
    }
  }

  static String getStatusLabel(TaskStatus status) {
    switch (status) {
      case TaskStatus.urgent: return 'URGENT';
      case TaskStatus.assigned: return 'ASSIGNED';
      case TaskStatus.inProgress: return 'IN PROGRESS';
      case TaskStatus.done: return 'DONE';
    }
  }

  static Color getStatusColor(TaskStatus status) {
    switch (status) {
      case TaskStatus.urgent: return const Color(0xFFF03E3E);
      case TaskStatus.assigned: return const Color(0xFF7048E8);
      case TaskStatus.inProgress: return const Color(0xFF3B5BDB);
      case TaskStatus.done: return const Color(0xFF2F9E44);
    }
  }

  static Color getStatusBgColor(TaskStatus status) {
    switch (status) {
      case TaskStatus.urgent: return const Color(0xFFFFE3E3);
      case TaskStatus.assigned: return const Color(0xFFEEE9FF);
      case TaskStatus.inProgress: return const Color(0xFFDBE4FF);
      case TaskStatus.done: return const Color(0xFFD3F9D8);
    }
  }

  static final List<String> categories = ['CS', 'STEM', 'Humanities', 'Fine Arts', 'Physics', 'Other'];

  static final Map<String, Color> scheduleColors = {
    'Blue': const Color(0xFF3B5BDB),
    'Green': const Color(0xFF2F9E44),
    'Purple': const Color(0xFF7048E8),
    'Orange': const Color(0xFFE67700),
    'Pink': const Color(0xFFE64980),
  };
}
