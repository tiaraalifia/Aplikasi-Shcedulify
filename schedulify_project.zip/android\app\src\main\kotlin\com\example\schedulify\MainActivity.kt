package com.example.schedulify

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
