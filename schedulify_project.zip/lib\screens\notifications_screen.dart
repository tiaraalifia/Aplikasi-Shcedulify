import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../state/app_state.dart';
import '../models/app_models.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AppState.instance;
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text('Notification Center',
            style: GoogleFonts.inter(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: theme.textTheme.bodyLarge?.color)),
        backgroundColor: isDark ? const Color(0xFF2A2A40) : Colors.white,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new_rounded,
              color: theme.textTheme.bodyLarge?.color, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          TextButton(
            onPressed: () => state.markAllNotificationsRead(),
            child: Text('Mark all as read',
                style: GoogleFonts.inter(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF3B5BDB))),
          ),
        ],
      ),
      body: ListenableBuilder(
        listenable: state,
        builder: (context, _) {
          final notifs = state.notifications;
          if (notifs.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.notifications_none_rounded,
                      size: 64, color: Colors.grey[500]),
                  const SizedBox(height: 16),
                  Text('All clear for now!',
                      style: GoogleFonts.inter(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.grey[400])),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
            itemCount: notifs.length,
            itemBuilder: (context, i) {
              final n = notifs[i];
              return _buildNotifCard(context, n, isDark);
            },
          );
        },
      ),
    );
  }

  Widget _buildNotifCard(BuildContext context, AppNotification n, bool isDark) {
    final cardColor = isDark
        ? (n.isRead ? const Color(0xFF22223A) : const Color(0xFF2A2A40))
        : (n.isRead ? Colors.white.withOpacity(0.6) : Colors.white);

    return GestureDetector(
      onTap: () => AppState.instance.markNotificationRead(n.id),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(16),
          border: n.isRead
              ? null
              : Border.all(
                  color: const Color(0xFF3B5BDB).withOpacity(0.2), width: 1.5),
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 10,
                offset: const Offset(0, 3)),
          ],
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: n.isOverdue
                    ? const Color(0xFFF03E3E).withOpacity(0.1)
                    : const Color(0xFF3B5BDB).withOpacity(0.1),
                shape: BoxShape.circle,
              ),
              child: Icon(
                n.isOverdue
                    ? Icons.priority_high_rounded
                    : Icons.notifications_active_outlined,
                color: n.isOverdue
                    ? const Color(0xFFF03E3E)
                    : const Color(0xFF3B5BDB),
                size: 20,
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Text(n.title,
                            style: GoogleFonts.inter(
                                fontSize: 14,
                                fontWeight: n.isRead
                                    ? FontWeight.w600
                                    : FontWeight.w800,
                                color: isDark
                                    ? Colors.white
                                    : const Color(0xFF1A1A2E))),
                      ),
                      Text(DateFormat('HH:mm').format(n.timestamp),
                          style: GoogleFonts.inter(
                              fontSize: 11, color: Colors.grey[500])),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(n.body,
                      style: GoogleFonts.inter(
                          fontSize: 13,
                          color: n.isRead
                              ? Colors.grey[500]
                              : Colors.grey[isDark ? 400 : 600])),
                ],
              ),
            ),
            if (!n.isRead) ...[
              const SizedBox(width: 8),
              Container(
                width: 8,
                height: 8,
                decoration: const BoxDecoration(
                    color: Color(0xFF3B5BDB), shape: BoxShape.circle),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
