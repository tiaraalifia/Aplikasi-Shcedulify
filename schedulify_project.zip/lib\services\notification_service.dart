import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../state/app_state.dart';

/// In-app notification service.
/// Checks every minute if tasks are upcoming (within 2h) or overdue.
class NotificationService {
  static final NotificationService instance = NotificationService._internal();
  NotificationService._internal();

  Timer? _timer;
  final Set<String> _notifiedTaskIds = {};
  BuildContext? _context;

  bool _enabled = true;
  bool get enabled => _enabled;
  set enabled(bool v) {
    _enabled = v;
    if (!v) _timer?.cancel();
  }

  void start(BuildContext context) {
    _context = context;
    if (!_enabled) return;
    _timer?.cancel();
    // Check immediately, then every 60 seconds
    _check();
    _timer = Timer.periodic(const Duration(seconds: 60), (_) => _check());
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
    _context = null;
  }

  /// Force-show a demo notification (called from Notifications settings)
  void showDemo(BuildContext context) {
    const title = '⏰  Deadline H-2 Jam!';
    const body = 'Tugas Mobile Programming harus dikumpul bentar lagi nih!';
    _showBanner(
      context: context,
      title: title,
      body: body,
      color: const Color(0xFFE67700),
    );
    AppState.instance.addNotification(title: title, body: body);
  }

  void _check() {
    final ctx = _context;
    if (ctx == null || !ctx.mounted || !_enabled) return;

    final state = AppState.instance;

    // Upcoming tasks (due within 2 hours)
    for (final task in state.getUpcomingTasks(hours: 2)) {
      final key = 'upcoming_${task.id}';
      if (!_notifiedTaskIds.contains(key)) {
        _notifiedTaskIds.add(key);
        final diff = task.dueDate.difference(DateTime.now());
        final timeStr =
            diff.inMinutes < 60 ? '${diff.inMinutes} menit' : '${diff.inHours} jam';
        
        final title = '⏰  Deadline H-$timeStr!';
        final body = 'Tugas "${task.title}" jangan lupa dikerjakan lho!';
        
        _showBanner(
          context: ctx,
          title: title,
          body: body,
          color: const Color(0xFFE67700),
        );
        state.addNotification(title: title, body: body);
      }
    }

    // Overdue tasks (show once)
    for (final task in state.overdueTasks) {
      final key = 'overdue_${task.id}';
      if (!_notifiedTaskIds.contains(key)) {
        _notifiedTaskIds.add(key);
        
        final title = '🚨  Tugas Kelewat!';
        final body = '"${task.title}" udah lewat deadline nih, parah bangett!';
        
        _showBanner(
          context: ctx,
          title: title,
          body: body,
          color: const Color(0xFFF03E3E),
        );
        state.addNotification(title: title, body: body, isOverdue: true);
      }
    }
  }

  void _showBanner({
    required BuildContext context,
    required String title,
    required String body,
    required Color color,
  }) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.2),
                shape: BoxShape.circle),
            child: Icon(
              title.contains('Overdue')
                  ? Icons.warning_amber_rounded
                  : Icons.alarm,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(title,
                    style: GoogleFonts.inter(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: Colors.white)),
                Text(body,
                    style: GoogleFonts.inter(
                        fontSize: 12,
                        color: Colors.white.withOpacity(0.85)),
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ]),
        backgroundColor: color,
        duration: const Duration(seconds: 6),
        behavior: SnackBarBehavior.floating,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 24),
      ),
    );
  }
}
