import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:google_fonts/google_fonts.dart';
import 'firebase_options.dart';
import 'screens/splash_screen.dart';
import 'state/app_state.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await AppState.instance.init();
  runApp(const SchedulifyApp());
}

class SchedulifyApp extends StatelessWidget {
  const SchedulifyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final isDark = AppState.instance.isDarkMode;

        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Schedulify',
          themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
          theme: ThemeData(
            useMaterial3: true,
            textTheme: GoogleFonts.interTextTheme(),
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF3B5BDB),
              brightness: Brightness.light,
            ),
            scaffoldBackgroundColor: const Color(0xFFF4F6FB),
          ),
          darkTheme: ThemeData(
            useMaterial3: true,
            textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme),
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF3B5BDB),
              brightness: Brightness.dark,
            ),
            scaffoldBackgroundColor: const Color(0xFF1A1A2E),
          ),
          home: const SplashScreen(),
        );
      },
    );
  }
}
